
const FRAME_W = 500; 
const FRAME_H = 500;
const MARGINS = {left: 70, top: 10, bottom: 50, right: 10};

const VIS_W = FRAME_W - MARGINS.left - MARGINS.right;
const VIS_H = FRAME_H - MARGINS.top - MARGINS.bottom; 

const FRAME1 = d3.select("#vis1")
                .append("svg")
                    .attr("width", FRAME_W)
                    .attr("height", FRAME_H)
                    .attr("class", "frame"); 

const FRAME2 = d3.select("#vis2")
                .append("svg")
                    .attr("width", FRAME_W)
                    .attr("height", FRAME_H)
                    .attr("class", "frame"); 

const FRAME3 = d3.select("#vis3")
                .append("svg")
                    .attr("width", FRAME_W)
                    .attr("height", FRAME_H)
                    .attr("class", "frame");  

(function init() {
    build_scatter_1();
    build_scatter_2();
    build_bar();  
})(); 

// length vs length (sepal on x)
function build_scatter_1() {
    d3.csv("data/iris.csv").then((data) => {

        // X scale 
        const MAX_SEPAL_L = d3.max(data, (d) => { 
                                return parseInt(d.Sepal_Length)
                            }) + 1; // add one extra to axis

        let X_SCALE1 = d3.scaleLinear()
                            .domain([0, MAX_SEPAL_L])
                            .range([0, VIS_W]); 

        // X axis
        FRAME1.append("g")
                .attr("transform", "translate(" + MARGINS.left + 
                    "," + (VIS_H + MARGINS.top) + ")")
                .call(d3.axisBottom(X_SCALE1));

        // Y scale 
        const MAX_PETAL_L = d3.max(data, (d) => { 
                                return parseInt(d.Petal_Length)
                            }) + 1; // add one extra to axis

        let Y_SCALE1 = d3.scaleLinear()
                            .domain([0, MAX_PETAL_L])
                            .range([VIS_H, 0]); 

        // Y axis
        FRAME1.append("g")
                .attr("transform", "translate(" + MARGINS.left + 
                    "," + MARGINS.top + ")")
                .call(d3.axisLeft(Y_SCALE1));

        // Add points
        FRAME1.selectAll("points")
                .data(data)
                .enter()
                    .append("circle")
                        .attr("cx", (d) => {
                            return (MARGINS.left + 
                                X_SCALE1(d.Sepal_Length));
                        })
                        .attr("cy", (d) => {
                            return (MARGINS.top + 
                                Y_SCALE1(d.Petal_Length));
                        })
                        .attr("r", 5)
                        .attr("class", (d) => {
                            return (d.Species + " point"); 
                        })
                        .attr("id", (d) => {
                            return d.id; 
                        }); 
    }); 
}

// width v width (sepal on x)
function build_scatter_2() {
    d3.csv("data/iris.csv").then((data) => { 

        // X scale 
        const MAX_SEPAL_W = d3.max(data, (d) => { 
                                return parseInt(d.Sepal_Width)
                            }) + 1; // add one extra to axis

        let X_SCALE2 = d3.scaleLinear()
                            .domain([0, MAX_SEPAL_W])
                            .range([0, VIS_W]); 

        // X axis
        FRAME2.append("g")
                .attr("transform", "translate(" + MARGINS.left + 
                    "," + (VIS_H + MARGINS.top) + ")")
                .call(d3.axisBottom(X_SCALE2));


        // Y scale 
        const MAX_PETAL_W = d3.max(data, (d) => { 
                                return parseInt(d.Petal_Width)
                            }) + 1; // add one extra to axis

        let Y_SCALE2 = d3.scaleLinear()
                            .domain([0, MAX_PETAL_W])
                            .range([VIS_H, 0]); 

        // Y axis
        FRAME2.append("g")
                .attr("transform", "translate(" + MARGINS.left + 
                    "," + MARGINS.top + ")")
                .call(d3.axisLeft(Y_SCALE2));

        // Add points
        FRAME2.selectAll("points")
                .data(data)
                .enter()
                    .append("circle")
                        .attr("cx", (d) => {
                            return (MARGINS.left + 
                                X_SCALE2(d.Sepal_Width));
                        })
                        .attr("cy", (d) => {
                            return (MARGINS.top + 
                                Y_SCALE2(d.Petal_Width));
                        })
                        .attr("r", 5)
                        .attr("class", (d) => {
                            return (d.Species + " point"); 
                        })
                        .attr("id", (d) => {
                            return d.id; 
                        }); 
    }); 
} 

// species counts 
function build_bar() {
    const data = [{Species: "virginica", Amount: 50},
                    {Species: "versicolor", Amount: 50}, 
                    {Species: "setosa", Amount: 50}];

    // X scale
    const X_SCALE = d3.scaleBand()
                        .range([0, VIS_W])
                        .domain(data.map(d => d.Species))
                        .padding(0.2); 
    // X axis
    FRAME3.append("g")
            .attr("transform", "translate(" + MARGINS.left +
                "," + (VIS_H + MARGINS.top) + ")")
            .call(d3.axisBottom(X_SCALE));  

    // Y scale 
    const Y_SCALE = d3.scaleLinear()
                        .domain([0, 60])
                        .range([VIS_H, 0]); 

    // Y axis 
    FRAME3.append("g")
            .attr("transform", "translate(" + MARGINS.left +
                "," + MARGINS.top + ")")
            .call(d3.axisLeft(Y_SCALE));  

    // Bars 
    FRAME3.selectAll("bars")
            .data(data)
            .enter()
            .append("rect")
                .attr("x", (d) => {
                    return (X_SCALE(d.Species) + MARGINS.left); 
                })
                .attr("y", (d) => {
                    return (Y_SCALE(d.Amount) + MARGINS.top);
                })
                .attr("height", (d) => {
                    return (VIS_H - Y_SCALE(d.Amount));
                })
                .attr("width", X_SCALE.bandwidth())
                .attr("class", (d) => {
                    return (d.Species + " bar"); 
                }); 
}




function isBrushed(brush_coords, cx, cy) {
    let x0 = brush_coords[0][0],
        x1 = brush_coords[1][0],
        y0 = brush_coords[0][1],
        y1 = brush_coords[1][1];
    return x0 <= cx && cx <= x1 && y0 <= cy && cy <= y1;    // This return TRUE or FALSE depending on if the points is in the selected area
}























