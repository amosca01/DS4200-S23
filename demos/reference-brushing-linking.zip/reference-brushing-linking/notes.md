
https://d3-graph-gallery.com/graph/interactivity_brush.html

# Application on a real scatterplot 

* Add brushing -- what does this chunk of code do?
* updateChart -- what does this chunk of code do?

# Moving forward to two scatterplots

* How is highlighting implemented in chart 1? 
* Do we have the same pieces for chart 2? Do we need to change anything? 
* Update starter code 
