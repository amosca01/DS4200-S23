
// JS File for class demo part 2
// Ab Mosca 
// Last moditifed: 02.07.2023


























