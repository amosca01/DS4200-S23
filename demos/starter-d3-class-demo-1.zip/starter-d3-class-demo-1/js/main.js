/*
D3 Class Demo 1
Prof. Mosca 
Modified: 10/04/2022
*/

console.log("hello"); 





