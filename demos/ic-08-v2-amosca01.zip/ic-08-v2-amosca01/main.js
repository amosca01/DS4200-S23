
// Constants for page set up 
const FRAME_W = 500; 
const FRAME_H = 500;
const MARGINS = {left: 70, top: 10, bottom: 50, right: 10};

const VIS_W = FRAME_W - MARGINS.left - MARGINS.right;
const VIS_H = FRAME_H - MARGINS.top - MARGINS.bottom; 

const FRAME1 = d3.select("#vis1")
                .append("svg")
                    .attr("width", FRAME_W)
                    .attr("height", FRAME_H)
                    .attr("class", "frame"); 


function build_bar_chart() {
    d3.csv("data/data.csv").then((data) => {

        // X scale
        const X_SCALE = d3.scaleBand() // for categorical data 
                            .range([0, VIS_W])
                            .domain(data.map(d => d.Category))
                            .padding(0.2); 
        // Add X axis
        FRAME1.append("g")
                .attr("transform", "translate(" + MARGINS.left +
                    "," + (VIS_H + MARGINS.top) + ")")
                .call(d3.axisBottom(X_SCALE));  

        // Y scale 
        const Y_SCALE = d3.scaleLinear()
                            .domain([0, 100000])
                            .range([VIS_H, 0]); 

        // Add Y axis 
        FRAME1.append("g")
                .attr("transform", "translate(" + MARGINS.left +
                    "," + MARGINS.top + ")")
                .call(d3.axisLeft(Y_SCALE));  

        // Add bars 
        FRAME1.selectAll("bars")
                .data(data)
                .enter()
                .append("rect")
                    .attr("x", (d) => {
                        // x pos depends on category 
                        return (X_SCALE(d.Category) + MARGINS.left); 
                    })
                    .attr("y", (d) => {
                        // start of rect depends on value 
                        return (Y_SCALE(d.Value) + MARGINS.top);
                    })
                    .attr("height", (d) => {
                        // height of bar should be height of vis - value
                        return (VIS_H - Y_SCALE(d.Value));
                    })
                    .attr("width", X_SCALE.bandwidth()) // width comes from X_SCALE for free
                    .attr("class", (d) => {
                        return (d.Category + " bar"); 
                    }); 
    })
}

build_bar_chart()